SELECT
  pg_terminate_backend($pid);
