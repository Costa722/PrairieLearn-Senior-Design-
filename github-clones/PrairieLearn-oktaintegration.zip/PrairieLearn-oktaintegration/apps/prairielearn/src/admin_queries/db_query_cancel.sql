SELECT
  pg_cancel_backend($pid);
