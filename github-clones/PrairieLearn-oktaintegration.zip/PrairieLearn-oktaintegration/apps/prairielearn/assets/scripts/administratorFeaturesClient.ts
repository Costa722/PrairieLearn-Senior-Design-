import './lib/morphdom';
import './lib/htmx';

import 'htmx.org/dist/ext/loading-states.js';
import 'htmx.org/dist/ext/morphdom-swap.js';
