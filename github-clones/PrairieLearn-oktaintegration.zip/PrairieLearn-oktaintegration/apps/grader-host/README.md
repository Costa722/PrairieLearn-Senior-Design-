# PrairieGrader

[![Dependabot Status](https://api.dependabot.com/badges/status?host=github&repo=PrairieLearn/PrairieGrader)](https://dependabot.com)

An executor for PrairieLearn external grading jobs.
