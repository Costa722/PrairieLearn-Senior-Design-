module.exports = {
  require: ['tsx'],
};
